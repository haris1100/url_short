Product Name
---------------
Materialize - Material Design Admin Template


Product Description
-------------------
The #1 selling material design admin template. Google Material Design Inspired UI with gradient colors, responsive design and amazing support are the reasons of our customers to fallen in love, making it the most trusted and complete Material Design Admin Template on the market.


Online Documentation
--------------------
You will find documentation in your downloaded zip file from ThemeForest. You can access documentation online as well.
Documentation URL: https://pixinvent.com/materialize-material-design-admin-template/html/documentation/


Change Log
----------
Read CHANGELOG.md file